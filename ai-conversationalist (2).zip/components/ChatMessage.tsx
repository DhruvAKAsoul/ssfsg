import React, { useEffect } from 'react';
import { Message, Part, TextPart, InlineDataPart } from '../types';
import LoadingIndicator from './LoadingIndicator';

// @ts-ignore - marked is loaded from a script tag in index.html
const marked = window.marked;
// @ts-ignore - hljs is loaded from a script tag in index.html
const hljs = window.hljs;

interface ChatMessageProps {
  message: Message;
  isLoading: boolean;
}

const UserIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
        <path fillRule="evenodd" d="M7.5 6a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 0 1-.437-.695Z" clipRule="evenodd" />
    </svg>
);

const ModelIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 text-purple-300">
        <path d="M14.25 6.375a3 3 0 1 1-5.25 2.25 3 3 0 0 1 5.25-2.25Zm-3.375 0a1.5 1.5 0 1 0-2.25 1.5 1.5 1.5 0 0 0 2.25-1.5ZM19.5 6.375a3 3 0 1 1-5.25 2.25 3 3 0 0 1 5.25-2.25Zm-3.375 0a1.5 1.5 0 1 0-2.25 1.5 1.5 1.5 0 0 0 2.25-1.5Z" />
        <path fillRule="evenodd" d="M2.515 11.253A9.749 9.749 0 0 0 12 21.75a9.749 9.749 0 0 0 9.485-10.497.75.75 0 0 0-.375-.625 1.5 1.5 0 0 0-1.125-2.625 1.5 1.5 0 0 1-1.5-1.5 8.25 8.25 0 0 0-15 0 1.5 1.5 0 0 1-1.5 1.5 1.5 1.5 0 0 0-1.125 2.625.75.75 0 0 0-.375.625ZM12 19.5a7.252 7.252 0 0 0 7.165-7.973 3.003 3.003 0 0 0-3.35-2.777 3 3 0 0 1-2.25-2.25A5.25 5.25 0 0 0 3 6.527a3.003 3.003 0 0 0-3.35 2.777A7.252 7.252 0 0 0 12 19.5Z" clipRule="evenodd" />
    </svg>
);

const ChatMessage: React.FC<ChatMessageProps> = ({ message, isLoading }) => {
  const isUser = message.role === 'user';
  
  const textParts = message.parts.filter((part): part is TextPart => 'text' in part);
  const imageParts = message.parts.filter((part): part is InlineDataPart => 'inlineData' in part);
  const textContent = textParts.map(part => part.text).join('');

  const messageRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messageRef.current) {
        const codeBlocks = messageRef.current.querySelectorAll('pre code');
        codeBlocks.forEach((block) => {
            hljs.highlightElement(block as HTMLElement);
        });
    }
  }, [textContent, isLoading]);

  const parsedContent = textContent ? marked.parse(textContent) : '';

  const bubbleClasses = isUser 
    ? "bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-l-2xl rounded-tr-2xl rounded-br-md" 
    : "bg-slate-700 text-slate-200 rounded-r-2xl rounded-tl-2xl rounded-bl-md";

  const alignmentClasses = isUser ? "justify-end" : "justify-start";
  
  const avatar = (
    <div className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center ${isUser ? 'bg-gradient-to-br from-blue-600 to-blue-700 text-white' : 'bg-slate-700'}`}>
      {isUser ? <UserIcon /> : <ModelIcon />}
    </div>
  );

  return (
    <div className={`flex items-start gap-3.5 p-4 animate-fade-in-up ${isUser ? 'flex-row-reverse' : ''}`}>
      {avatar}
      <div className="flex flex-col max-w-2xl" ref={messageRef}>
        <div className={`p-4 shadow-md ${bubbleClasses}`}>
          
          {imageParts.length > 0 && (
            <div className={`grid grid-cols-2 gap-2 ${textContent ? 'mb-3' : ''}`}>
              {imageParts.map((part, index) => (
                <a href={`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`} target="_blank" rel="noopener noreferrer">
                  <img
                    key={index}
                    src={`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`}
                    alt={`Uploaded content ${index + 1}`}
                    className="max-w-full h-auto rounded-lg border-2 border-slate-600/50 hover:border-purple-500 transition-all"
                  />
                </a>
              ))}
            </div>
          )}

          {isLoading ? (
            <LoadingIndicator />
          ) : (
            <div
              className="prose prose-invert prose-sm max-w-none text-slate-200"
              dangerouslySetInnerHTML={{ __html: parsedContent }}
            />
          )}

        </div>
      </div>
    </div>
  );
};

export default ChatMessage;