import React from 'react';

const SparkleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-purple-400">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456Z" />
    </svg>
);


const Header: React.FC = () => {
  return (
    <header className="bg-slate-900/50 backdrop-blur-xl border-b border-white/10 p-4 sticky top-0 z-10">
      <div className="container mx-auto max-w-4xl flex items-center gap-4">
        <SparkleIcon />
        <div>
            <h1 className="text-xl font-bold text-slate-100 tracking-wide">AI ChatBot</h1>
            <p className="text-sm text-slate-400">Your intelligent chat partner powered by Gemini</p>
        </div>
      </div>
    </header>
  );
};

export default Header;