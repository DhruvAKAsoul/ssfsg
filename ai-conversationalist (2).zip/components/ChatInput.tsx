import React, { useState, useRef, useEffect, useCallback } from 'react';

// FIX: Add type definitions for the browser's SpeechRecognition API to resolve TypeScript errors.
interface SpeechRecognitionAlternative {
  transcript: string;
}
interface SpeechRecognitionResult {
  [index: number]: SpeechRecognitionAlternative;
  length: number;
}
interface SpeechRecognitionResultList {
  [index: number]: SpeechRecognitionResult;
  length: number;
}
interface SpeechRecognitionEvent {
  results: SpeechRecognitionResultList;
}
interface SpeechRecognitionErrorEvent {
  error: string;
}
interface SpeechRecognition {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: (event: SpeechRecognitionEvent) => void;
  onend: () => void;
  onerror: (event: SpeechRecognitionErrorEvent) => void;
  start: () => void;
  stop: () => void;
}

declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}

// Type for the data sent to the parent component
interface InlineData {
  mimeType: string;
  data: string; // base64 string
}

// Type for managing file previews in the component's state
interface FilePreview {
  name: string;
  url: string;
  type: string;
  file: File;
}

interface ChatInputProps {
  onSendMessage: (message: string, files: InlineData[]) => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [text, setText] = useState('');
  const [files, setFiles] = useState<FilePreview[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const textBeforeListenRef = useRef<string>('');
  const shouldSendMessageOnStop = useRef(false);

  const onSendMessageRef = useRef(onSendMessage);
  useEffect(() => {
    onSendMessageRef.current = onSendMessage;
  }, [onSendMessage]);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';
    recognition.onresult = (event) => {
      let fullTranscript = '';
      for (let i = 0; i < event.results.length; i++) {
        fullTranscript += event.results[i][0].transcript;
      }
      setText(textBeforeListenRef.current + fullTranscript);
    };
    recognition.onend = () => {
      setIsListening(false);
      if (shouldSendMessageOnStop.current) {
        const finalTranscript = textareaRef.current?.value.trim() ?? '';
        if (finalTranscript) {
          onSendMessageRef.current(finalTranscript, []);
          setText('');
        }
        shouldSendMessageOnStop.current = false;
      }
    };
    recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
      shouldSendMessageOnStop.current = false;
    };
    recognitionRef.current = recognition;
    return () => recognition.stop();
  }, []);
  
  // Cleanup object URLs when component unmounts or files change
  useEffect(() => {
    return () => {
      files.forEach(file => URL.revokeObjectURL(file.url));
    };
  }, [files]);

  const resizeTextarea = useCallback(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      const maxHeight = 200; // Corresponds to max-h-52 in tailwind
      textareaRef.current.style.height = `${Math.min(scrollHeight, maxHeight)}px`;
      textareaRef.current.style.overflowY = scrollHeight > maxHeight ? 'auto' : 'hidden';
    }
  }, []);

  useEffect(() => {
    resizeTextarea();
  }, [text, resizeTextarea]);

  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = error => reject(error);
    });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedText = text.trim();
    if ((!trimmedText && files.length === 0) || isLoading) return;

    const imageParts: InlineData[] = await Promise.all(
      files.map(async (filePreview) => ({
        mimeType: filePreview.type,
        data: await fileToBase64(filePreview.file)
      }))
    );

    onSendMessage(trimmedText, imageParts);
    setText('');
    setFiles([]); 
    if (isListening) {
      shouldSendMessageOnStop.current = false;
      recognitionRef.current?.stop();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };
  
  const handleAttachmentClick = () => fileInputRef.current?.click();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []);
    if (selectedFiles.length > 0) {
      const newFiles = selectedFiles.map(file => ({
        name: file.name,
        url: URL.createObjectURL(file),
        type: file.type,
        file: file
      }));
      setFiles(prev => [...prev, ...newFiles]);
    }
    if (event.target) event.target.value = '';
  };

  const removeFile = (fileName: string) => {
    setFiles(prev => prev.filter(f => f.name !== fileName));
  };


  const handleMicClick = () => {
    if (!recognitionRef.current) return;
    if (isListening) {
      shouldSendMessageOnStop.current = true;
      recognitionRef.current.stop();
    } else {
      shouldSendMessageOnStop.current = false;
      textBeforeListenRef.current = text ? text.trim() + ' ' : '';
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-xl border-t border-white/10 p-4 sticky bottom-0">
      <div className="container mx-auto max-w-4xl">
        {files.length > 0 && (
          <div className="mb-3 p-2 bg-slate-800/50 rounded-lg border border-slate-700">
            <div className="flex flex-wrap gap-3">
              {files.map(file => (
                <div key={file.name} className="relative group">
                  <img src={file.url} alt={file.name} className="h-20 w-20 object-cover rounded-md border-2 border-slate-600 group-hover:border-purple-500 transition-colors" />
                  <button
                    onClick={() => removeFile(file.name)}
                    className="absolute top-0 right-0 -m-1.5 bg-slate-700 rounded-full p-0.5 text-slate-300 hover:bg-red-500 hover:text-white transition-all transform scale-75 opacity-0 group-hover:opacity-100 group-hover:scale-100"
                    aria-label={`Remove ${file.name}`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
                      <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
        <form onSubmit={handleSubmit} className="flex items-end gap-2.5">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/png, image/jpeg, image/webp, image/gif"
            multiple
            className="hidden"
          />
          <button
            type="button"
            onClick={handleAttachmentClick}
            disabled={isLoading}
            className="bg-slate-700/80 text-slate-300 rounded-full h-11 w-11 flex items-center justify-center flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-600 transition-all duration-200 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-slate-900"
            aria-label="Attach files"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
              <path fillRule="evenodd" d="M18.97 3.659a2.25 2.25 0 0 0-3.182 0l-10.5 10.5a.75.75 0 0 0 1.06 1.06l10.5-10.5a.75.75 0 0 1 1.06 0l1.5 1.5a.75.75 0 0 1 0 1.06l-6.75 6.75a.75.75 0 0 0 0 1.06l1.5 1.5a.75.75 0 0 0 1.06 0l6.75-6.75a2.25 2.25 0 0 0 0-3.182l-1.5-1.5ZM12.97 8.159a.75.75 0 0 0-1.06 0l-3.75 3.75a.75.75 0 0 0 0 1.06l1.5 1.5a.75.75 0 0 0 1.06 0l3.75-3.75a.75.75 0 0 0 0-1.06l-1.5-1.5Z" clipRule="evenodd" />
              <path d="M8.625 3.375a3.75 3.75 0 0 0-5.303 0l-1.5 1.5a3.75 3.75 0 0 0 0 5.303l6.75 6.75a3.75 3.75 0 0 0 5.303 0l1.5-1.5a3.75 3.75 0 0 0 0-5.303l-6.75-6.75Z" />
            </svg>
          </button>
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message..."
            rows={1}
            className="flex-1 bg-slate-800 text-slate-200 placeholder-slate-400 rounded-xl py-2.5 px-4 resize-none focus:outline-none focus:ring-2 focus:ring-purple-500/80 transition-all duration-200 max-h-52"
            disabled={isLoading}
          />
          {recognitionRef.current && (
            <button
              type="button"
              onClick={handleMicClick}
              disabled={isLoading}
              className="bg-slate-700/80 text-slate-300 rounded-full h-11 w-11 flex items-center justify-center flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-600 transition-all duration-200 hover:scale-110 relative focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-slate-900"
              aria-label={isListening ? 'Stop recording and send message' : 'Record audio message'}
            >
              {isListening && <span className="absolute inset-0 rounded-full bg-red-500/40 animate-pulse"></span>}
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={`w-6 h-6 z-10 ${isListening ? 'text-red-400' : 'text-slate-300'}`}>
                <path d="M8.25 4.5a3.75 3.75 0 1 1 7.5 0v8.25a3.75 3.75 0 1 1-7.5 0V4.5Z" />
                <path d="M6 10.5a.75.75 0 0 1 .75.75v1.5a5.25 5.25 0 1 0 10.5 0v-1.5a.75.75 0 0 1 1.5 0v1.5a6.75 6.75 0 1 1-13.5 0v-1.5a.75.75 0 0 1 .75-.75Z" />
              </svg>
            </button>
          )}
          <button
            type="submit"
            disabled={isLoading || (!text.trim() && files.length === 0)}
            className="bg-purple-600 text-white rounded-full h-11 w-11 flex items-center justify-center flex-shrink-0 disabled:bg-slate-600 disabled:cursor-not-allowed disabled:shadow-none hover:bg-purple-700 transition-all duration-200 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-slate-900 shadow-lg shadow-purple-600/30 enabled:hover:shadow-purple-600/40"
            aria-label="Send message"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />
              </svg>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInput;