
import { GoogleGenAI, Chat } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const model = 'gemini-2.5-flash';

export function createChatSession(): Chat {
  const chat: Chat = ai.chats.create({
    model: model,
    config: {
      systemInstruction: 'You are a friendly and helpful AI assistant. Your goal is to provide accurate, relevant, and engaging responses. You are designed to simulate human-like conversation and serve as a foundation for advanced intelligent systems.',
    },
  });
  return chat;
}
