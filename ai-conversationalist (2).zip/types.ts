export type Role = "user" | "model";

export interface TextPart {
  text: string;
}

export interface InlineData {
  mimeType: string;
  data: string; // base64 string
}

export interface InlineDataPart {
  inlineData: InlineData;
}

// A part can be either text or image data.
export type Part = TextPart | InlineDataPart;

export interface Message {
  role: Role;
  parts: Part[];
}
