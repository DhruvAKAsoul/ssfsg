import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { Chat } from '@google/genai';
import type { Message, Part, InlineData } from './types';
import { createChatSession } from './services/geminiService';
import Header from './components/Header';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [chat, setChat] = useState<Chat | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
        setChat(createChatSession());
        setMessages([
          {
            role: 'model',
            parts: [{ text: "Hello! I'm an AI conversationalist. I can now understand images and format my responses with lists, code blocks, and more. How can I help you today?" }],
          },
        ]);
    } catch (error) {
        console.error("Failed to initialize chat session:", error);
        setMessages([
          {
            role: 'model',
            parts: [{ text: "Error: Could not start the chat session. Please ensure your API key is configured correctly." }],
          },
        ]);
    }
  }, []);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = useCallback(async (text: string, files: InlineData[]) => {
    if (!chat || isLoading) return;

    const messageParts: Part[] = [];
    
    // Add image parts first
    files.forEach(file => {
        messageParts.push({ 
            inlineData: {
                mimeType: file.mimeType,
                data: file.data
            } 
        });
    });

    // Then add the text part
    if (text) {
        messageParts.push({ text });
    }

    if (messageParts.length === 0) return;

    const userMessage: Message = { role: 'user', parts: messageParts };
    
    // Add user message and a placeholder for the model's response
    setMessages(prev => [...prev, userMessage, { role: 'model', parts: [{ text: '' }] }]);
    setIsLoading(true);

    try {
      const stream = await chat.sendMessageStream({ message: messageParts });
      
      for await (const chunk of stream) {
        const chunkText = chunk.text;
        setMessages(prev => {
          const newMessages = [...prev];
          const lastMessage = newMessages[newMessages.length - 1];
          if (lastMessage.role === 'model') {
            const firstPart = lastMessage.parts[0];
            if (firstPart && 'text' in firstPart) {
              firstPart.text += chunkText;
            }
          }
          return newMessages;
        });
      }
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: Message = {
        role: 'model',
        parts: [{ text: 'Sorry, something went wrong. Please try again.' }],
      };
      setMessages(prev => {
        const newMessages = [...prev];
        // Replace placeholder with error message
        newMessages[newMessages.length - 1] = errorMessage;
        return newMessages;
      });
    } finally {
      setIsLoading(false);
    }
  }, [chat, isLoading]);


  return (
    <div className="bg-animated-gradient text-white min-h-screen flex flex-col font-sans">
      <Header />
      <main ref={chatContainerRef} className="flex-1 overflow-y-auto">
        <div className="container mx-auto max-w-4xl">
          {messages.map((msg, index) => {
            const isLastMessage = index === messages.length - 1;
            const isModelLoading = isLoading && isLastMessage && msg.role === 'model';
            // Don't render the empty placeholder if it's not the final loading message.
            if (msg.parts.every(p => 'text' in p && p.text === '') && !isModelLoading) {
                return null;
            }
            return (
              <ChatMessage 
                key={index} 
                message={msg} 
                isLoading={isModelLoading}
              />
            );
          })}
        </div>
      </main>
      <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
};

export default App;